/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_1_ed_2;

import java.awt.List;
import java.util.ArrayList;

/**
 *
 * @author carlo
 */
public class Nodo_arbol{
private int Identificador_Personas;  
    private String Categoria_Personas;
    ArrayList<Nodo_arbol> hijos;
    
    
    public Nodo_arbol(int Identificador_Personas,String Categoria_Personas) {
        this.Identificador_Personas = Identificador_Personas;
        this.Categoria_Personas = Categoria_Personas;
        this.hijos = new ArrayList<>();
        
    }

        public int getIdentificador_Personas() {
            return Identificador_Personas;
        }

        public void setIdentificador_Personas(int Identificador_Personas) {
            this.Identificador_Personas = Identificador_Personas;
        }

        public String getCategoria_Personas() {
            return Categoria_Personas;
        }

        public void setCategoria_Personas(String Categoria_Personas) {
            this.Categoria_Personas = Categoria_Personas;
        }

    public ArrayList<Nodo_arbol> getHijos() {
        return hijos;
    }

     public void addHijo( Nodo_arbol hijo){
     hijos.add(hijo);
   } 

    
    

    
    
     
    }
        
        
                    

