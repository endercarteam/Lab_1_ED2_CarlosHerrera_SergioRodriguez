/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_1_ed_2;

/**
 *
 * @author carlo
 */
public class Nodo_arbol {
private int Identificador_Personas;  
    private String Categoria_Personas;
     Nodo_arbol[] hijos;  
    
   
    public Nodo_arbol(int Identificador_Personas,String Categoria_Personas,int nhijos) {
        this.Identificador_Personas = Identificador_Personas;
        this.Categoria_Personas = Categoria_Personas;
        this.hijos = new Nodo_arbol[nhijos];
    }

        public int getIdentificador_Personas() {
            return Identificador_Personas;
        }

        public void setIdentificador_Personas(int Identificador_Personas) {
            this.Identificador_Personas = Identificador_Personas;
        }

        public String getCategoria_Personas() {
            return Categoria_Personas;
        }

        public void setCategoria_Personas(String Categoria_Personas) {
            this.Categoria_Personas = Categoria_Personas;
        }

    
    

    
    public Nodo_arbol[] getHijos() {
        return hijos;
    }

    
    public Nodo_arbol getHijo(int indice) {
        return hijos[indice];
    }

    
    public void setHijo(int indice, Nodo_arbol hijo) {
        hijos[indice] = hijo;
    }
    public void add(Nodo_arbol nuevo){
    
    }    
    }
    }
        
        
                    

