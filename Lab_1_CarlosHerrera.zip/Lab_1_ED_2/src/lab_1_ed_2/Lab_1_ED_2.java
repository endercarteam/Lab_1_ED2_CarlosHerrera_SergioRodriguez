/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_1_ed_2;

/**
 *
 * @author carlo
 */
public class Lab_1_ED_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Principal f = new Principal();
        f.setVisible (true);
    }
    
}
