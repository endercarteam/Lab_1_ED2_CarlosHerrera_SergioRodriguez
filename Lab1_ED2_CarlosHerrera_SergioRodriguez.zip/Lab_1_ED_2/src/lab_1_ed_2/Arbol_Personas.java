/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_1_ed_2;

/**
 *
 * @author carlo
 */
public class Arbol_Personas {
    
  Nodo_arbol Root;
  public Arbol_Personas(){
      this.Root = null;
  }
  public void insertar(int Identificador_Personas,String Categoria_Personas,int nhijos) {
        if (Root == null) {
             Root = new Nodo_arbol(Identificador_Personas, Categoria_Personas, nhijos);
        } else {
            insertarAux(Root, Identificador_Personas, Categoria_Personas, nhijos);
        }
    }

    private void insertarAux(Nodo_arbol nodo, int Identificador_Personas,String Categoria_Personas,int nhijos) {
        Nodo_arbol nuevo = new Nodo_arbol(Identificador_Personas, Categoria_Personas, nhijos);
        nodo.hijos.(nuevo);
    }
    
    }
    

