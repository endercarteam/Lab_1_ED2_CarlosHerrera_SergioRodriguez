/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_1_ed_2;

/**
 *
 * @author carlo
 */
public class Arbol_Personas {
     
  static Nodo_arbol Root =  new Nodo_arbol(0, "Clientes");
  
  public Arbol_Personas(int Identificador_Personas, String Categoria_Personas){
     
      this.Root = new Nodo_arbol(Identificador_Personas, Categoria_Personas);
  }
   
 
 
   public void addHijo_arbol(Nodo_arbol padre, Nodo_arbol hijo) {
     
        padre.addHijo(hijo);
    }
    }
    
    
    

